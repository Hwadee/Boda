CREATE TRIGGER emp_id_unify
AFTER INSERT ON employee
FOR EACH ROW
  BEGIN
INSERT into emp_detail (emp_detail_id)
VALUES (new.emp_id);
end;
