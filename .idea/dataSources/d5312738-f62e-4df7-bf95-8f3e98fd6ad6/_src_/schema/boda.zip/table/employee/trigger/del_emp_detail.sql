CREATE TRIGGER del_emp_detail
AFTER DELETE ON employee
FOR EACH ROW
  BEGIN
DELETE from emp_detail WHERE emp_detail_id=old.emp_id;
END;
