CREATE TRIGGER generate_return_message
AFTER UPDATE ON loan
FOR EACH ROW
  BEGIN
declare i int default 1;
if (new.loan_state="已发放" AND NOT EXISTS(select * from return_loan WHERE new.loan_id=return_loan.loan_id)) THEN
	WHILE i<=new.number_of_stages DO
	INSERT INTO return_loan (loan_id,should_return_money,should_return_date,which_stage)
	VALUES (new.loan_id,new.loan_money*(1+new.rate_of_interest)/new.number_of_stages,
	DATE_ADD(new.return_start_date,INTERVAL ((i-1)*12*new.return_years/new.number_of_stages) MONTH),i);
	set i=i+1;
	END WHILE;
end if;
end;
