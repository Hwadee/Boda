CREATE PROCEDURE auto_over_time_set()
  BEGIN
update return_loan r,loan l
set r.return_state="逾期未还",l.loan_state="存在逾期"
where (r.return_money is null or r.return_money!=r.should_return_money)
 and r.should_return_date<current_date and l.loan_id=r.loan_id;

END;
